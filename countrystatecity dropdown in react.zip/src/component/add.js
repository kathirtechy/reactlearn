import React from "react";

class Add extends React.Component {
  state = {
    email: "",
    password: "",
    address: "",
    education: "",
    country: "",
    state: "",
    city: "",
    validationerr: {},
    countryarr: [],
    statearr: [],
    cityarr: []
  };

  async componentDidMount() {
    let apiurl = await fetch(`http://localhost/restapi/country.php`);
    let result2 = await apiurl.json();
    this.setState({
      countryarr: result2
    });
  }

  statefun = async e => {
    // console.log("state---------------", e.target.value);
    if (e.target.name == "country") {
      let cidd = e.target.value;
      let apiurl = await fetch(
        `http://localhost/restapi/state.php?cid=${cidd}`
      );
      let result1 = await apiurl.json();
      //console.log("r--------", result1);
      this.setState({
        statearr: result1
      });
    }
  };

  cityfun = async e => {
    //console.log("state---------------", e.target.value);
    if (e.target.name == "state") {
      let cidd = e.target.value;
      let apiurl = await fetch(`http://localhost/restapi/city.php?sid=${cidd}`);
      let result1 = await apiurl.json();
      // console.log("r--------", result1);
      this.setState({
        cityarr: result1
      });
    }
  };

  handleChange = e => {
    // console.log(e);
    let name = e.target.name;
    let value = e.target.value;
    if (e.target.multiple) {
      value = Array.from(e.target.selectedOptions, option => option.value);
    }

    if (name == "country") {
      this.statefun(e);
    }
    if (name == "state") {
      this.cityfun(e);
    }
    this.setState({
      [name]: value
    });

    console.log(this.state);
  };

  handleSubmit = e => {
    e.preventDefault();
    //console.log(this.state);
    this.validatefun();
  };

  validatefun = () => {
    let errors = {};
    const {
      email,
      password,
      address,
      education,
      country,
      state,
      city
    } = this.state;

    let isValid = true;
    if (!email) {
      errors["email"] = "please enter Email";
      isValid = false;
    }
    if (!password) {
      errors["password"] = "please enter password";
      isValid = false;
    }
    if (!address) {
      errors["address"] = "please enter address";
      isValid = false;
    }
    if (!education) {
      errors["education"] = "please enter education";
      isValid = false;
    }
    if (!country) {
      errors["country"] = "please enter country";
      isValid = false;
    }
    if (!state) {
      errors["state"] = "please enter state";
      isValid = false;
    }
    if (!city) {
      errors["city"] = "please enter city";
      isValid = false;
    }
    //this.state.validationerr = errors;

    this.setState({
      validationerr: errors
    });

    return isValid;
  };

  render() {
    console.log(this.state.countryarr);
    const {
      email: emailerror,
      password: passworderr,
      address: addresserr,
      education: educationerr,
      country: countryerr,
      state: stateerr,
      city: cityerr
    } = this.state.validationerr;
    return (
      <>
        <div className="container">
          <form onSubmit={this.handleSubmit}>
            <div className="form-row">
              <div className="form-group col-md-6">
                <label for="inputEmail4">Email</label>
                <input
                  type="email"
                  onChange={this.handleChange}
                  className="form-control"
                  id="inputEmail4"
                  placeholder="Email"
                  name="email"
                />
                <span className="text-danger">{emailerror}</span>
              </div>
              <div className="form-group col-md-6">
                <label for="inputPassword4">Password</label>
                <input
                  type="password"
                  className="form-control"
                  id="inputPassword4"
                  onChange={this.handleChange}
                  placeholder="Password"
                  name="password"
                />
                <span className="text-danger">{passworderr}</span>
              </div>
            </div>
            <div className="form-row">
              <div className="form-group col-md-6">
                <label for="inputAddress">Address</label>
                <input
                  type="text"
                  className="form-control"
                  id="inputAddress"
                  onChange={this.handleChange}
                  placeholder="1234 Main St"
                  name="address"
                />
                <span className="text-danger">{addresserr}</span>
              </div>
              <div className="form-group col-md-6">
                <label for="inputAddress">Education</label>
                <select
                  multiple
                  id=""
                  name="education"
                  onChange={this.handleChange}
                  className="form-control"
                >
                  <option value="BE">BE</option>
                  <option value="MBA">MBA</option>
                  <option value="MCA">MCA</option>
                </select>
                <span className="text-danger">{educationerr}</span>
              </div>
            </div>
            <div className="form-row">
              <div className="form-group col-md-4">
                <label for="inputCity">Country</label>
                <select
                  name="country"
                  onChange={this.handleChange}
                  className="form-control"
                >
                  <option>Choose Country</option>
                  {this.state.countryarr.map(x => (
                    <option value={x.id}>{x.cname}</option>
                  ))}
                </select>
                <span className="text-danger">{countryerr}</span>
              </div>
              <div className="form-group col-md-4">
                <label for="inputState">State</label>
                <select
                  id="inputState"
                  onChange={this.handleChange}
                  name="state"
                  className="form-control"
                >
                  <option>Choose...</option>
                  {this.state.statearr.map(x => (
                    <option key={x.id} value={x.id}>
                      {x.sname}
                    </option>
                  ))}
                </select>
                <span className="text-danger">{stateerr}</span>
              </div>
              <div className="form-group col-md-4">
                <label for="inputCity">City</label>
                <select
                  id="inputState"
                  onChange={this.handleChange}
                  name="city"
                  className="form-control"
                >
                  <option>Choose...</option>
                  {this.state.cityarr.map(x => (
                    <option value={x.id}>{x.cityname}</option>
                  ))}
                </select>
                <span className="text-danger">{cityerr}</span>
              </div>
            </div>

            <button type="submit" className="btn btn-primary">
              Sign in
            </button>
          </form>
        </div>
      </>
    );
  }
}

export default Add;

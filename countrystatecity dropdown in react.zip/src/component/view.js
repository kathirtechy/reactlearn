import React from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";

class View extends React.Component {
  state = {
    data: []
  };

  async componentDidMount() {
    let apiurl = await fetch(`https://jsonplaceholder.typicode.com/posts`);
    let result = await apiurl.json();
    this.setState({
      data: result
    });
  }

  render() {
    return (
      <>
        <div className="container">
          <h2>View Datas</h2>

          <table className="table table-dark table-hover">
            <thead>
              <tr>
                <th>id</th>
                <th>title</th>
                <th>body</th>
                <th>action</th>
              </tr>
            </thead>
            <tbody>
              {this.state.data.map((x, index) => (
                <tr key={index}>
                  <td>{index + 1}</td>
                  <td>{x.title}</td>
                  <td>{x.body}</td>
                  <td>
                    <Link to={`/viewone/${x.id}`} className="btn btn-primary">
                      view
                    </Link>
                    <Link to={`/edit/${x.id}`} className="btn btn-primary">
                      Edit
                    </Link>
                  </td>
                </tr>
              ))}

              <Switch />
            </tbody>
          </table>
        </div>
      </>
    );
  }
}

export default View;

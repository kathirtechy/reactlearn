import React from "react";
import "./style.css";
import View from "./component/view";
import Add from "./component/add";
import Editval from "./component/edit";
import Viewone from "./component/viewone";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";

export default function App() {
  return (
    <>
      <div class="container">
        <div class="list-group">
          <Link to="/" className="list-group-item">
            View
          </Link>
          <Link to="/add" className="list-group-item">
            Add
          </Link>
        </div>
      </div>
      <Switch>
        <Route path="/" exact component={View} />

        <Route path="/add" component={Add} />

        <Route path="/edit/:id" component={Editval} />
        <Route path="/viewone/:id" component={Viewone} />
      </Switch>
    </>
  );
}

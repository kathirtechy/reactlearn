import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";

function View() {
  const [data, setData] = useState([]);

  useEffect(async () => {
    try {
      const response = await fetch(
        `https://jsonplaceholder.typicode.com/posts`
      );
      const json = await response.json();
      setData(json);
    } catch (e) {
      console.error(e);
    }
  }, []);

  return (
    <>
      <div className="container">
        <h2>View Datas</h2>

        <table className="table table-dark table-hover">
          <thead>
            <tr>
              <th>id</th>
              <th>title</th>
              <th>body</th>
              <th>action</th>
            </tr>
          </thead>
          <tbody>
            {data.map((x, index) => (
              <tr key={index}>
                <td>{index + 1}</td>
                <td>{x.title}</td>
                <td>{x.body}</td>
                <td>
                  <Link to={`/viewone/${x.id}`} className="btn btn-primary">
                    view
                  </Link>
                  <Link to={`/edit/${x.id}`} className="btn btn-primary">
                    Edit
                  </Link>
                </td>
              </tr>
            ))}

            <Switch />
          </tbody>
        </table>
      </div>
    </>
  );
}

export default View;

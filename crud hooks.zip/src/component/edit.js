import React, { useState, useEffect } from "react";

function Editval(props) {
  const intialstate = {
    title: "",
    body: ""
  };
  console.log("t------", props);
  //const paramid = 4;
  //const paramid = props.match.params.id;
  const [data, setData] = useState(intialstate);
  //const [data1, setData1] = useState([]);
  const paramid = props.match.params.id;
  useEffect(async () => {
    try {
      const response = await fetch(
        `https://jsonplaceholder.typicode.com/posts/${paramid}`
      );
      const json = await response.json();
      setData(json);
      console.log("i----", json);
    } catch (e) {
      console.error(e);
    }
  }, []);

  function handleChange(e) {
    // console.log(e);
    let name = e.target.name;
    let value = e.target.value;
    setData({ ...data, [name]: value });

    console.log("c----", data);
  }

  return (
    <>
      <div className="container">
        <form>
          <div className="form-row">
            <div className="form-group col-md-6">
              <label for="inputEmail4">title</label>
              <textarea
                name="title"
                value={data.title}
                onChange={handleChange}
                className="form-control"
              />
            </div>
            <div className="form-group col-md-6">
              <label for="inputPassword4">Body</label>
              <textarea
                name="body"
                value={data.body}
                onChange={handleChange}
                className="form-control"
              />
            </div>
          </div>

          <button type="submit" className="btn btn-primary">
            Sign in
          </button>
        </form>
      </div>
    </>
  );
}

export default Editval;

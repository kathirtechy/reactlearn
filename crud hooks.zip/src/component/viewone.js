import React, { useState, useEffect } from "react";

function Viewone(props) {
  const paramid = props.match.params.id;
  const [data, setData] = useState([]);

  useEffect(async () => {
    try {
      const response = await fetch(
        `https://jsonplaceholder.typicode.com/posts/${paramid}`
      );
      const json = await response.json();
      setData(json);
    } catch (e) {
      console.error(e);
    }
  }, []);

  return (
    <>
      <h2>view profile</h2>
      <ul class="list-group">
        <li class="list-group-item ">{data.id}</li>
        <li class="list-group-item">{data.title}</li>
        <li class="list-group-item">{data.body}</li>
      </ul>
    </>
  );
}

export default Viewone;

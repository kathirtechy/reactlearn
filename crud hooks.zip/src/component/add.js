import React, { useEffect, useState } from "react";

function Add() {
  let intialstate = {
    email: "",
    password: "",
    address: "",
    education: "",
    country: "",
    state: "",
    city: ""
  };

  const err = { validation_err: {} };

  const [data, setData] = useState(intialstate);
  const [data1, setData1] = useState(err);

  function handleChange(e) {
    // console.log(e);
    let name = e.target.name;
    let value = e.target.value;
    if (e.target.multiple) {
      value = Array.from(e.target.selectedOptions, option => option.value);
    }
    setData({
      ...data,
      [name]: value
    });

    console.log(data);
  }

  function validatefun() {
    const { email, password, address, education, country, state, city } = data;
    let errors = {};
    let isValid = true;
    if (!email) {
      errors["email"] = "please enter Email";
      isValid = false;
    }
    if (!password) {
      errors["password"] = "please enter password";
      isValid = false;
    }
    if (!address) {
      errors["address"] = "please enter address";
      isValid = false;
    }
    if (!education) {
      errors["education"] = "please enter education";
      isValid = false;
    }
    if (!country) {
      errors["country"] = "please enter country";
      isValid = false;
    }
    if (!state) {
      errors["state"] = "please enter state";
      isValid = false;
    }
    if (!city) {
      errors["city"] = "please enter city";
      isValid = false;
    }
    //this.state.validationerr = errors;

    setData1(errors);

    return isValid;
  }

  function handleSubmit(e) {
    console.log("errr===", data1);
    e.preventDefault();
    validatefun();
  }

  const {
    email: emailerror,
    password: passworderr,
    address: addresserr,
    education: educationerr,
    country: countryerr,
    state: stateerr,
    city: cityerr
  } = data1;
  return (
    <>
      <div className="container">
        <form onSubmit={handleSubmit}>
          <div className="form-row">
            <div className="form-group col-md-6">
              <label for="inputEmail4">Email</label>
              <input
                type="email"
                onChange={handleChange}
                className="form-control"
                id="inputEmail4"
                placeholder="Email"
                name="email"
              />
              <span className="text-danger">{emailerror}</span>
            </div>
            <div className="form-group col-md-6">
              <label for="inputPassword4">Password</label>
              <input
                type="password"
                className="form-control"
                id="inputPassword4"
                onChange={handleChange}
                placeholder="Password"
                name="password"
              />
              <span className="text-danger">{passworderr}</span>
            </div>
          </div>
          <div className="form-row">
            <div className="form-group col-md-6">
              <label for="inputAddress">Address</label>
              <input
                type="text"
                className="form-control"
                id="inputAddress"
                onChange={handleChange}
                placeholder="1234 Main St"
                name="address"
              />
              <span className="text-danger">{addresserr}</span>
            </div>
            <div className="form-group col-md-6">
              <label for="inputAddress">Education</label>
              <select
                multiple
                id=""
                name="education"
                onChange={handleChange}
                className="form-control"
              >
                <option value="BE">BE</option>
                <option value="MBA">MBA</option>
                <option value="MCA">MCA</option>
              </select>
              <span className="text-danger">{educationerr}</span>
            </div>
          </div>
          <div className="form-row">
            <div className="form-group col-md-4">
              <label for="inputCity">Country</label>
              <select
                name="country"
                onChange={handleChange}
                className="form-control"
              >
                <option>Choose Country</option>
                <option value="india">india</option>
                <option value="USA">USA</option>
                <option value="UAE">UAE</option>
              </select>
              <span className="text-danger">{countryerr}</span>
            </div>
            <div className="form-group col-md-4">
              <label for="inputState">State</label>
              <select
                id="inputState"
                onChange={handleChange}
                name="state"
                className="form-control"
              >
                <option>Choose...</option>
                <option value="Tamilnadu">Tamilnadu</option>
                <option value="California">California</option>
                <option value="saudiarabia">saudiarabia</option>
              </select>
              <span className="text-danger">{stateerr}</span>
            </div>
            <div className="form-group col-md-4">
              <label for="inputCity">City</label>
              <select
                id="inputState"
                onChange={handleChange}
                name="city"
                className="form-control"
              >
                <option>Choose...</option>
                <option value="chennai">chennai</option>
                <option value="Bangalore">Bangalore</option>
                <option value="coimbatore">coimbatore</option>
                <option value="losvegas">losvegas</option>
              </select>
              <span className="text-danger">{cityerr}</span>
            </div>
          </div>

          <button type="submit" className="btn btn-primary">
            Sign in
          </button>
        </form>
      </div>
    </>
  );
}

export default Add;

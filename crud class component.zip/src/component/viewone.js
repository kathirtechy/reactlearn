import React from "react";

class Viewone extends React.Component {
  state = {
    data: []
  };

  async componentDidMount() {
    console.log("t----", this.props);
    const paramid = this.props.match.params.id;
    let apiurl = await fetch(
      `https://jsonplaceholder.typicode.com/posts/${paramid}`
    );
    let result = await apiurl.json();
    this.setState({
      data: result
    });
  }

  render() {
    return (
      <>
        <h2>view profile</h2>
        <ul class="list-group">
          <li class="list-group-item ">{this.state.data.id}</li>
          <li class="list-group-item">{this.state.data.title}</li>
          <li class="list-group-item">{this.state.data.body}</li>
        </ul>
      </>
    );
  }
}

export default Viewone;

import React from "react";

class Edit extends React.Component {
  state = {
    title: "",
    body: "",
    data: []
  };

  async componentDidMount() {
    console.log("t----", this.props);
    const paramid = this.props.match.params.id;
    let apiurl = await fetch(
      `https://jsonplaceholder.typicode.com/posts/${paramid}`
    );
    let result = await apiurl.json();
    this.setState({
      data: result
    });

    this.setState({
      title: this.state.data.title,
      body: this.state.data.body
    });
  }

  handleChange = e => {
    // console.log(e);
    let name = e.target.name;
    let value = e.target.value;
    this.setState({
      [name]: value
    });

    console.log("c----", this.state);
  };
  render() {
    return (
      <>
        <div className="container">
          <form>
            <div className="form-row">
              <div className="form-group col-md-6">
                <label for="inputEmail4">title</label>
                <textarea
                  name="title"
                  onChange={this.handleChange}
                  value={this.state.title}
                  className="form-control"
                />
              </div>
              <div className="form-group col-md-6">
                <label for="inputPassword4">Body</label>
                <textarea
                  name="body"
                  onChange={this.handleChange}
                  value={this.state.body}
                  className="form-control"
                />
              </div>
            </div>

            <button type="submit" className="btn btn-primary">
              Sign in
            </button>
          </form>
        </div>
      </>
    );
  }
}

export default Edit;

import React from "react";
import View from "./component/view";
import Add from "./component/add";
import Edit from "./component/edit";
import Viewone from "./component/viewone";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";

export default function App() {
  return (
    <>
      <div class="container">
        <div class="list-group">
          <Link to="/" className="list-group-item">
            View
          </Link>
          <Link to="/add" className="list-group-item">
            Add
          </Link>
          <Link to="/edit" className="list-group-item">
            edit
          </Link>
        </div>
      </div>
      <Switch>
        <Route path="/" exact component={View} />

        <Route path="/add" component={Add} />

        <Route path="/edit/:id" component={Edit} />
        <Route path="/viewone/:id" component={Viewone} />
      </Switch>
    </>
  );
}
